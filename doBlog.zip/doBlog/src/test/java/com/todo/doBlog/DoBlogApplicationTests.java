package com.todo.doBlog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
