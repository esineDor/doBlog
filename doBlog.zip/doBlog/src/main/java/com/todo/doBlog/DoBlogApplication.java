package com.todo.doBlog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoBlogApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoBlogApplication.class, args);
	}

}
